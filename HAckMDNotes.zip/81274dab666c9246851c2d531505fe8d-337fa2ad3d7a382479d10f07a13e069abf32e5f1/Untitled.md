
(Esmeralda A.)

Instagram
- Collab posts(seperate accounts are able to share same content)
- Direct messages and group chats
- Story features

Shop
- shop recommendations
- Real-time tracking and inventory information

Crunchyroll
- Ongoing anime series updated weekly (or depending on series updates)
- Catalog of a variety of series (each under their own genre)
- Each have their own rating, description, allows user to watch subbed or dubbed

App ideas
* Music app
  - catalog of music genres and artists
  - keep artists song list updated
----------------------------------------------

Corey T
yelp- the ability to post reviews of local businesses

instagram- posting videos and stories of poeples lives

youtube- a user defined content creator base.

App Ideas

instagram like app for businesses and customers to leave a live review of the company.
Allowing an open conversation with customers and businesses